<?php

define('SQUID_USER',  'sneakerhandbook'); // Don't use special chars or space
define('SQUID_PASS', 'sh12345');  // Don't use special chars or space
define('SQUID_PORT',  3128);  // use ports 500 to 10000 to be safe.


define('ROOT_PASSWORD', 'NoP@ssword1');
define('SSH_PUBLIC_KEY_FILE', '/home/boby/.ssh/id_rsa.pub');


#####################################################################
# 100TB.COM                                                         #
#####################################################################

define('API_KEY_100TB', 'zOkkBCMctBJYjCeVmL7tteEf2f1jBjtO0e8960fGeU8hX36UWWhLOXYbJXMmH0wX');


#####################################################################
# DO NOT EDIT                                                       #
#####################################################################

$squidUser = SQUID_USER;
$squidPassword = SQUID_PASS;
$squidPort = SQUID_PORT;
