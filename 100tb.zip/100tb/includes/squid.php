<?php
/******************************************************************************
 *
 * AUTHOR: admin@hhostonnet.com
 * WEBSITE: https://blog.HostOnNet.com
 *
 * Create virtual servers in cloud with Squid 3 proxy ready to go
 * Edit config.php to set proxy username and password.
 *
 ******************************************************************************/

function installSquidProxy($serverIP, $serverUser, $serverPassword) {
    $ssh = new SSH();
    
    echo "Installing Squid Proxy\n";
    
    while (! $ssh->connect($serverIP, 22)) {
        echo "Not server available. Waiting for server to boot.\n";
        sleep(15);
    }

    if (! $ssh->login($serverUser, $serverPassword)) {
        die("Login failed to server $serverIP,$serverUser, $serverPassword\n");
    } else {
        echo "Logged in.\n";
    }

    $ssh->exec('/usr/bin/apt update');
    $ssh->exec('/usr/bin/apt -y install apache2-utils squid3');
    $ssh->exec('touch /etc/squid/passwd');
    $ssh->exec('/usr/bin/touch /etc/squid/blacklist.acl');
    $ssh->exec("rm -f /etc/squid/squid.conf");
    $squidConfigFile = __DIR__ . '/../assets/squid.conf';
    if (SQUID_PORT == 3128) {
        $ssh->copy($squidConfigFile, '/etc/squid/squid.conf', 0700);    
    } else {
        $fp = fopen($squidConfigFile, 'r');
        $fileContent = fread($fp, filesize($squidConfigFile));
        fclose($fp);
        $fileContent = str_replace('http_port 3128', "http_port " . SQUID_PORT, $fileContent);
        $tmpFileName = tempnam("/tmp", "squid");
        $fp = fopen($tmpFileName, "w");
        fwrite($fp, $fileContent);
        fclose($fp);
        $ssh->copy($tmpFileName, '/etc/squid/squid.conf', 0700);
    }
    $ssh->exec('/usr/bin/htpasswd -b -c /etc/squid/passwd ' . SQUID_USER . ' ' . SQUID_PASS);
    $ssh->exec("iptables -I INPUT -p tcp -m tcp --dport " . SQUID_PORT . " -j ACCEPT");
    $ssh->exec('service squid restart');
    echo "Squid Proxy installation completed on $serverIP\n";
}

function verifySSH($serverIP, $serverUser, $serverPassword) {
    $con = @ssh2_connect($serverIP, 22);

    if (!$con) {
        return false;
    }

    $auth = @ssh2_auth_password($con, $serverUser, $serverPassword);

    if (!$auth) {
        return false;
    }

    if (!file_exists(SSH_PUBLIC_KEY_FILE)) {
        die("Public key file not found : " . SSH_PUBLIC_KEY_FILE);
    }

    ssh2_exec($con, 'mkdir /root/.ssh');
    ssh2_scp_send($con, SSH_PUBLIC_KEY_FILE, '/root/.ssh/authorized_keys2', 0600);
    ssh2_exec($con, 'chmod -R 600 /root/.ssh');
    return true;
}
