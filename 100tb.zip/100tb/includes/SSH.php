<?php

class SSH
{
    public $connection;
    
    function connect($host, $port) {
        $this->connection = @ssh2_connect($host, $port);
        if ($this->connection) {
            return true;
        } else {
            return false;
        }
    }
    
    public function login($username, $password) {
        if (ssh2_auth_password($this->connection, $username, $password)) {
           return true;
        } else {
            return false;
        }
    }
    
    function exec($command) {
        $stream = ssh2_exec($this->connection, $command.' 2>&1');
        stream_set_blocking($stream, true);
        $data = "";
        while($buf = fread($stream, 4096)) {
            $data .= $buf;
        }
        fclose($stream);
        return $data;
    }

    function copy($source, $destination, $mode = '0700') {
        $steam = ssh2_scp_send($this->connection, $source, $destination, $mode);
    }
    
}
