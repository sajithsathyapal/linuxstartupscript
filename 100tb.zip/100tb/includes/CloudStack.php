<?php

class CloudStack
{
    public static function getVMPassword($vmId) {
        
        global $client;
        
        $options = [
            'id' => $vmId
        ];

        $getVMPassword = $client->command('getVMPassword', $options);

        $encryptedpassword = base64_decode($getVMPassword['getvmpasswordresponse']['password']['encryptedpassword']);

        $fp = fopen("/tmp/pw-encoded.txt","w");
        fwrite($fp, $encryptedpassword);
        fclose($fp);

        $privateKeyPath = __DIR__ . "/../sshkey/hostonnet";

        if (!file_exists($privateKeyPath)) {
            echo "Private Key not found: $privateKeyPath\n";
            exit;
        }

        if (!file_exists("/usr/bin/openssl")) {
            echo "OpenSSL not installed.\n";
            exit;
        }

        $cmd = "/usr/bin/openssl rsautl -decrypt -in /tmp/pw-encoded.txt -out /tmp/pw-human.txt -inkey $privateKeyPath";
        @exec("$cmd");

        sleep(1);

        $file = file("/tmp/pw-human.txt");

        return $file[0];
    }

}
