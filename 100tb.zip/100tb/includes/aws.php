<?php
/******************************************************************************
 *
 * AUTHOR: admin@hhostonnet.com
 * WEBSITE: https://blog.HostOnNet.com
 *
 * Create virtual servers in cloud with Squid 3 proxy ready to go
 * Edit config.php to set proxy username and password.
 *
 ******************************************************************************/

$awsRegions = [
    [
        'region' => 'us-east-1',
        'location' => 'US East (N. Virginia)',
        'image-id' => 'ami-80861296'
    ],
    [
        'region' => 'us-east-2',
        'location' => 'US East (Ohio)',
        'image-id' => 'ami-618fab04'
    ],
    [
        'region' => 'us-west-1',
        'location' => 'US West (N. California)',
        'image-id' => 'ami-2afbde4a'
    ],
    [
        'region' => 'us-west-2',
        'location' => 'US West (Oregon)',
        'image-id' => 'ami-efd0428f'
    ],
    [
        'region' => 'ca-central-1',
        'location' => 'Canada (Central)',
        'image-id' => 'ami-b3d965d7'
    ],
    [
        'region' => 'eu-west-1',
        'location' => 'EU (Ireland)',
        'image-id' => 'ami-a8d2d7ce'
    ],
    [
        'region' => 'eu-central-1',
        'location' => 'EU (Frankfurt)',
        'image-id' => 'ami-060cde69'
    ],
    [
        'region' => 'eu-west-2',
        'location' => 'EU (London)',
        'image-id' => 'ami-f1d7c395'
    ],

];


class AWS {
    
    public function getInstanceIp($instanceId, $region) 
    {
        $cmd = 'aws ec2 describe-instances --region=' . $region . ' --instance-ids  '. $instanceId;
        $result = CliApi::run($cmd);
        if (!empty($result->Reservations[0]->Instances[0]->PublicIpAddress)) {
            return $result->Reservations[0]->Instances[0]->PublicIpAddress;
        } else {
            return false;
        }
    }
    
    public function deleteServer($instanceId, $region) {
        $cmd = 'aws ec2 terminate-instances --instance-ids ' . $instanceId . ' --region ' . $region;
        $result = CliApi::run($cmd);
        //echo "EC2 Instance " . $result->TerminatingInstances[0]->InstanceId ." terminated.\n";
    }
    
}
