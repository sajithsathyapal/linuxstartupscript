
=============================================================
GENERAL SETUP
=============================================================

sudo apt update
sudo apt install -y git php php-zip php-curl php-ssh2


curl -s https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
sudo chmod +x /usr/local/bin/composer

cd ~/100tb
composer install


=============================================================
Set aliases
=============================================================

nano ~/.bashrc

Add following to end

alias 100tb-create='/usr/bin/php ~/100tb/100tb-create.php'
alias 100tb-delete='/usr/bin/php ~/100tb/100tb-delete.php'



=============================================================
100TB.com
=============================================================

Login to

https://console.100tb.com

Create an API Key and add it in config.php

If you don't want a server to be deleted for any reason, go to

https://console.100tb.com/#/apps/cloud

Change servers label to something else.

