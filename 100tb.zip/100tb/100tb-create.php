<?php
/******************************************************************************
 *
 * AUTHOR: Sneaker Handbook
 * WEBSITE: https://twitter.com/SneakerHandbook
 *
 * Create virtual servers in cloud with Squid 3 proxy ready to go
 * Edit config.php to set proxy username and password.
 *
 ******************************************************************************/

require 'config.php';
require 'functions.php';
require 'includes/100tb.php';
require 'includes/squid.php';
require 'includes/SSH.php';

showStartBanner();

$teraClient = new TeraClient(API_KEY_100TB);

$serverData = array(
    'planId' => '2446',
    'locationId' => '6',
    'templateId' => '527',
    'label' => 'string',
    'hostname' => 'string',
    'password' => ROOT_PASSWORD,
    'backups' => 'false',
    'billHourly' => 'true'
);

echo "\nSelect 100TB Region: \n\n";

try {
    $regions = $teraClient->get('/vps.json/locations', array());
} catch (Exception $e) {
    print $e->getMessage();
    exit;
}

foreach ($regions as $key => $region) {
    echo ($key + 1) . '. ' . $region['title'] . "\n";
}

echo "\nSelect: ";

$userSelection = (int) readInput();
$userSelection = $userSelection - 1;

if (!isset($regions[$userSelection])) {
    die("Invalid data centr location");
}

$selectedRegion = $regions[$userSelection];

$serverData['locationId'] = $selectedRegion['id'];

echo "\n";
echo "How many server you want to create: ";

$numServer = readInput();

if (! is_numeric($numServer)) {
    echo "Invalid number provided.\n";
    echo "Aborting...\n";
    exit();
}

showWaitMessage($numServer, $selectedRegion['title']);


try {
    $templates = $teraClient->get('/vps.json/templates/{locationId}', array('locationId' => $serverData['locationId']));
} catch (Exception $e) {
    print $e->getMessage();
    exit;
}

$ServerTemplate = array();

foreach ($templates as $template) {
    if ($template['label'] == 'Ubuntu 16.04 x64') {
        $ServerTemplate = $template;
    }
}

if (empty($ServerTemplate)) {
    die("Failed to find server template");
}

$serverData['templateId'] = $ServerTemplate['id'];

$myServers = array();

for ($i=0; $i< $numServer; $i++) {
    $serverData['hostname'] = 'hostonnet-' . str_pad($i, "3", "0", STR_PAD_LEFT);
    $serverData['label'] = $serverData['hostname'];
    showLine('-');
    echo "Creating server " . $serverData['label'] . "\n";
    showLine('-');
    try {
        $myServer = $teraClient->post('/vps.json', $serverData);
        echo "Server created with IP: " . $myServer['ip'] . "\n";
        sleep(20);
        installSquidProxy($myServer['ip'], 'root', ROOT_PASSWORD);
    } catch (Exception $e) {
        echo "Failed to create server\n";
        print $e->getMessage();
        exit;
    }

    $myServers[] = $myServer['ip'];
    
    sleep(15);
}

listProxy($myServers, true);
