<?php
/******************************************************************************
 *
 * AUTHOR: Sneaker Handbook
 * WEBSITE: https://twitter.com/SneakerHandbook
 *
 * Create virtual servers in cloud with Squid 3 proxy ready to go
 * Edit config.php to set proxy username and password.
 *
 ******************************************************************************/

require 'config.php';
require 'functions.php';
require 'includes/100tb.php';

showStartBanner();

$teraClient = new TeraClient(API_KEY_100TB);

try {
    $servers = $teraClient->get('/vps.json/servers',[]);
} catch (Exception $e) {
    print $e->getMessage();
    exit;
}

$serversDeleted = 0;
$serversFailed = 0;

foreach ($servers['r'] as $server) {
    if (strpos($server['label'],'hostonnet') !== false) {
        try {
            $response = $teraClient->delete('/vps.json/servers/{id}', array('id' => $server['id']));
            if ($response) {
                echo "[OK] Server " . $server['ip_address'] . " deleted.\n";
                $serversDeleted++;
            } else {
                echo "[ERROR] Failed to delete server " . $server['ip_address'] . ".\n";
                $serversFailed++;
            }
        } catch (Exception $e) {
            print $e->getMessage();
            exit;
        }
    }
}

echo "\n\n";

if ($serversFailed > 0) {
    echo "ERROR DELETING SERVERS. PLEASE TRY AGAIN";
} else if ($serversDeleted > 0) {
    echo "Servers deleted. Please login to 100tb.com account and verify";
} else {
    echo "No servers found.";
}

echo "\n\n";
echo "\nLogin to your 100TB.COM account and make sure there is no running instances.\n";
echo "\n";
